var firstChestOpeningForCustomNameOfChest = true;
var colorsForCustomNameOfChest = "80cd123459"
var totalChestCountForCustomNameOfChest = 0;
var chestCountForCustomNameOfChest = 0;
updateTotalChestCountForCustomNameOfChest()

register("guiRender", function (x, y, gui) {
  if (gui.toString().indexOf("Chest") != -1) {
    if (firstChestOpeningForCustomNameOfChest) {
      firstChestOpeningForCustomNameOfChest = false;
      var chestName = getInventoryName(Player.getOpenedInventory())
      if (chestName.indexOf("Loot Chest") != -1) {
        chestCountForCustomNameOfChest += 1
        Player.getOpenedInventory().getContainer().func_85151_d().func_110133_a("§" + colorsForCustomNameOfChest[chestCountForCustomNameOfChest % 10] + chestName + " #" + chestCountForCustomNameOfChest + " Tot: " + (chestCountForCustomNameOfChest + totalChestCountForCustomNameOfChest))
      }
    }
  }
});

register("tick", function () {
  if (getInventoryName(Player.getOpenedInventory()) == "container") {
    firstChestOpeningForCustomNameOfChest = true;
  }
});


function getInventoryName(inventory) {
  // ContainerChest.getLowerChestInventory().getName()
  // derives from 'net.minecraft.util.INameable#getName()'
  // needs to be in a try catch because IInventory might not be INameable
  try {
    return inventory.getContainer().func_85151_d().func_70005_c_()
  } catch (error) {
    return "container"
  }
}

function updateTotalChestCountForCustomNameOfChest(player, callback) {
  var request = new XMLHttpRequest();
  request.open("GET", "https://api.wynncraft.com/v2/player/" + Player.getName() + "/stats", true);
  request.setCallbackMethod(function (response, error) {
    var result = JSON.parse(response.responseText)
    totalChestCountForCustomNameOfChest = result["data"][0]["classes"].reduce(function (a, b) { return a + b["chestsFound"] }, 0)
  });
  request.send()
}
